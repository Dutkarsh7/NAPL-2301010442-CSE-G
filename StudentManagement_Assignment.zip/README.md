# F# Practical Assignment: Student Management System
**Unit 2 (F#) Assessment - Sessions 6 to 8**

---

## 1. Domain Modeling (Types and Records)
- **Discriminated Union:** `Grade` (`Distinction`, `Pass`, `Fail`) represents the academic standing of a student.
- **Record Type:** `Student` represents individual student records with fields `Id`, `Name`, `Course`, and `Score`.

```fsharp
type Grade =
    | Distinction
    | Pass
    | Fail

type Student = {
    Id: int
    Name: string
    Course: string
    Score: int
}
```

---

## 2. Higher-Order Functions & Pattern Matching
- **Pattern Matching (`match ... with`):** Evaluates a student's score to categorize them into `Distinction`, `Pass`, or `Fail`. Also translates `Grade` types to strings.
- **Higher-Order Function `List.filter`:** Filters the student collection to retain only those with passing scores (`Score >= 40`).
- **Higher-Order Function `List.map`:** Transforms each `Student` record into a formatted report string including their calculated grade.

```fsharp
let assignGrade (score: int) : Grade =
    match score with
    | s when s >= 75 -> Distinction
    | s when s >= 40 -> Pass
    | _ -> Fail

let getPassedStudents (students: Student list) : Student list =
    students |> List.filter (fun s -> s.Score >= 40)

let formatStudentReports (students: Student list) : string list =
    students
    |> List.map (fun s ->
        let grade = assignGrade s.Score
        sprintf "ID: %d | Name: %s | Course: %s | Score: %d | Grade: %s"
            s.Id s.Name s.Course s.Score (gradeToString grade))
```

---

## 3. Database Persistence (CRUD with Async Workflows)
Using **SQLite** (`Microsoft.Data.Sqlite`) with F# `async { ... }` computation expressions:
- **CREATE:** `insertStudentAsync` inserts new student records into the database.
- **READ:** `readStudentsAsync` retrieves all student records from the database.
- **UPDATE:** `updateStudentScoreAsync` updates the score of an existing student.
- **DELETE:** `deleteStudentAsync` removes a student record by ID.

---

## Execution Output

```text
======================================================
   F# Practical Assessment: Student Management System
======================================================

--- STEP 1: Initializing Database Table ---
Database initialized successfully.

--- STEP 2: Inserting Records (CRUD: Create) ---
[CREATE] Added/Replaced Student: Alice (Score: 82)
[CREATE] Added/Replaced Student: Bob (Score: 35)
[CREATE] Added/Replaced Student: Charlie (Score: 65)
[CREATE] Added/Replaced Student: Diana (Score: 90)

--- STEP 3: Reading All Records (CRUD: Read) ---

--- STEP 4: Processing with Higher-Order Functions (map, filter) & Pattern Matching ---

[ALL STUDENTS REPORT] (Generated using List.map & Pattern Matching):
  - ID: 101 | Name: Alice | Course: Computer Science | Score: 82 | Grade: Distinction
  - ID: 102 | Name: Bob | Course: Mathematics | Score: 35 | Grade: Fail
  - ID: 103 | Name: Charlie | Course: Physics | Score: 65 | Grade: Pass
  - ID: 104 | Name: Diana | Course: Computer Science | Score: 90 | Grade: Distinction

[PASSED STUDENTS ONLY] (Filtered using List.filter where Score >= 40):
  - Alice (82 marks)
  - Charlie (65 marks)
  - Diana (90 marks)

--- STEP 5: Updating Record (CRUD: Update) ---
[UPDATE] Updated Student ID 102 with new score: 55 (Affected rows: 1)

[REPORTS AFTER UPDATE]:
  - ID: 101 | Name: Alice | Course: Computer Science | Score: 82 | Grade: Distinction
  - ID: 102 | Name: Bob | Course: Mathematics | Score: 55 | Grade: Pass
  - ID: 103 | Name: Charlie | Course: Physics | Score: 65 | Grade: Pass
  - ID: 104 | Name: Diana | Course: Computer Science | Score: 90 | Grade: Distinction

--- STEP 6: Deleting Record (CRUD: Delete) ---
[DELETE] Removed Student with ID 103 (Affected rows: 1)

[REMAINING STUDENTS IN DATABASE]:
  - ID: 101 | Name: Alice | Course: Computer Science | Score: 82 | Grade: Distinction
  - ID: 102 | Name: Bob | Course: Mathematics | Score: 55 | Grade: Pass
  - ID: 104 | Name: Diana | Course: Computer Science | Score: 90 | Grade: Distinction

======================================================
   Assessment Demonstration Completed Successfully!
======================================================
```

---

## How to Run
1. Make sure .NET SDK is installed.
2. Open terminal in the project directory.
3. Run:
   ```bash
   dotnet run
   ```
