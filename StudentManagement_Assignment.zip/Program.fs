open System
open Microsoft.Data.Sqlite

// ==========================================
// 1. DOMAIN MODEL (Types and Records)
// ==========================================

// Grade category using Discriminated Union
type Grade =
    | Distinction
    | Pass
    | Fail

// Student record
type Student = {
    Id: int
    Name: string
    Course: string
    Score: int
}

// ==========================================
// 2. HIGHER-ORDER FUNCTIONS & PATTERN MATCHING
// ==========================================

// Pattern matching: determine Grade based on score
let assignGrade (score: int) : Grade =
    match score with
    | s when s >= 75 -> Distinction
    | s when s >= 40 -> Pass
    | _ -> Fail

// Pattern matching: convert Grade to string display
let gradeToString (grade: Grade) : string =
    match grade with
    | Distinction -> "Distinction"
    | Pass -> "Pass"
    | Fail -> "Fail"

// Higher-order function (filter): get only passed students
let getPassedStudents (students: Student list) : Student list =
    students |> List.filter (fun s -> s.Score >= 40)

// Higher-order function (map): format student details into reports
let formatStudentReports (students: Student list) : string list =
    students
    |> List.map (fun s ->
        let grade = assignGrade s.Score
        sprintf "ID: %d | Name: %s | Course: %s | Score: %d | Grade: %s"
            s.Id s.Name s.Course s.Score (gradeToString grade))

// ==========================================
// 3. DATABASE PERSISTENCE (CRUD with Async)
// ==========================================

let connectionString = "Data Source=students.db"

// Initialize database table
let initDbAsync () = async {
    use conn = new SqliteConnection(connectionString)
    do! conn.OpenAsync() |> Async.AwaitTask
    let sql = """
        CREATE TABLE IF NOT EXISTS Students (
            Id INTEGER PRIMARY KEY,
            Name TEXT NOT NULL,
            Course TEXT NOT NULL,
            Score INTEGER NOT NULL
        );
    """
    use cmd = new SqliteCommand(sql, conn)
    let! _ = cmd.ExecuteNonQueryAsync() |> Async.AwaitTask
    ()
}

// CREATE operation (Insert)
let insertStudentAsync (s: Student) = async {
    use conn = new SqliteConnection(connectionString)
    do! conn.OpenAsync() |> Async.AwaitTask
    let sql = "INSERT OR REPLACE INTO Students (Id, Name, Course, Score) VALUES (@id, @name, @course, @score);"
    use cmd = new SqliteCommand(sql, conn)
    cmd.Parameters.AddWithValue("@id", s.Id) |> ignore
    cmd.Parameters.AddWithValue("@name", s.Name) |> ignore
    cmd.Parameters.AddWithValue("@course", s.Course) |> ignore
    cmd.Parameters.AddWithValue("@score", s.Score) |> ignore
    let! _ = cmd.ExecuteNonQueryAsync() |> Async.AwaitTask
    printfn "[CREATE] Added/Replaced Student: %s (Score: %d)" s.Name s.Score
}

// READ operation (Select All)
let readStudentsAsync () = async {
    use conn = new SqliteConnection(connectionString)
    do! conn.OpenAsync() |> Async.AwaitTask
    let sql = "SELECT Id, Name, Course, Score FROM Students;"
    use cmd = new SqliteCommand(sql, conn)
    use! reader = cmd.ExecuteReaderAsync() |> Async.AwaitTask
    
    let studentList = ResizeArray<Student>()
    while reader.Read() do
        let student = {
            Id = reader.GetInt32(0)
            Name = reader.GetString(1)
            Course = reader.GetString(2)
            Score = reader.GetInt32(3)
        }
        studentList.Add(student)
        
    return studentList |> Seq.toList
}

// UPDATE operation (Update Score)
let updateStudentScoreAsync (id: int) (newScore: int) = async {
    use conn = new SqliteConnection(connectionString)
    do! conn.OpenAsync() |> Async.AwaitTask
    let sql = "UPDATE Students SET Score = @score WHERE Id = @id;"
    use cmd = new SqliteCommand(sql, conn)
    cmd.Parameters.AddWithValue("@score", newScore) |> ignore
    cmd.Parameters.AddWithValue("@id", id) |> ignore
    let! rows = cmd.ExecuteNonQueryAsync() |> Async.AwaitTask
    printfn "[UPDATE] Updated Student ID %d with new score: %d (Affected rows: %d)" id newScore rows
}

// DELETE operation (Delete by Id)
let deleteStudentAsync (id: int) = async {
    use conn = new SqliteConnection(connectionString)
    do! conn.OpenAsync() |> Async.AwaitTask
    let sql = "DELETE FROM Students WHERE Id = @id;"
    use cmd = new SqliteCommand(sql, conn)
    cmd.Parameters.AddWithValue("@id", id) |> ignore
    let! rows = cmd.ExecuteNonQueryAsync() |> Async.AwaitTask
    printfn "[DELETE] Removed Student with ID %d (Affected rows: %d)" id rows
}

// ==========================================
// MAIN WORKFLOW
// ==========================================

[<EntryPoint>]
let main argv =
    async {
        printfn "======================================================"
        printfn "   F# Practical Assessment: Student Management System"
        printfn "======================================================"

        // Step 1: Initialize Database
        printfn "\n--- STEP 1: Initializing Database Table ---"
        do! initDbAsync()
        printfn "Database initialized successfully."

        // Step 2: Create initial domain records
        let sampleStudents = [
            { Id = 101; Name = "Alice"; Course = "Computer Science"; Score = 82 }
            { Id = 102; Name = "Bob"; Course = "Mathematics"; Score = 35 }
            { Id = 103; Name = "Charlie"; Course = "Physics"; Score = 65 }
            { Id = 104; Name = "Diana"; Course = "Computer Science"; Score = 90 }
        ]

        // Step 3: Insert (Create) records into SQLite Database
        printfn "\n--- STEP 2: Inserting Records (CRUD: Create) ---"
        for s in sampleStudents do
            do! insertStudentAsync s

        // Step 4: Read records from Database
        printfn "\n--- STEP 3: Reading All Records (CRUD: Read) ---"
        let! currentStudents = readStudentsAsync()
        
        printfn "\n--- STEP 4: Processing with Higher-Order Functions (map, filter) & Pattern Matching ---"
        printfn "\n[ALL STUDENTS REPORT] (Generated using List.map & Pattern Matching):"
        let reports = formatStudentReports currentStudents
        reports |> List.iter (printfn "  - %s")

        printfn "\n[PASSED STUDENTS ONLY] (Filtered using List.filter where Score >= 40):"
        let passed = getPassedStudents currentStudents
        passed |> List.iter (fun s -> printfn "  - %s (%d marks)" s.Name s.Score)

        // Step 5: Update a record
        printfn "\n--- STEP 5: Updating Record (CRUD: Update) ---"
        // Let's say Bob (Id 102) re-took the exam and scored 55
        do! updateStudentScoreAsync 102 55

        // Read again to verify update
        let! updatedStudents = readStudentsAsync()
        printfn "\n[REPORTS AFTER UPDATE]:"
        formatStudentReports updatedStudents |> List.iter (printfn "  - %s")

        // Step 6: Delete a record
        printfn "\n--- STEP 6: Deleting Record (CRUD: Delete) ---"
        do! deleteStudentAsync 103

        // Final check
        let! finalStudents = readStudentsAsync()
        printfn "\n[REMAINING STUDENTS IN DATABASE]:"
        formatStudentReports finalStudents |> List.iter (printfn "  - %s")

        printfn "\n======================================================"
        printfn "   Assessment Demonstration Completed Successfully!"
        printfn "======================================================"
    }
    |> Async.RunSynchronously

    0
